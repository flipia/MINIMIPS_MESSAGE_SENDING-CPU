function machineCode = assembleLine(line, instructionSet, registers)
    % 1. 토큰화 및 파싱
    tokens = tokenize(line); % 토큰화
    [opcodeKey, operands] = parseTokens(tokens); % 파싱

    % 2. 명령어 유효성 검사
    if ~isKey(instructionSet, opcodeKey)
        error('유효하지 않은 명령어: %s', opcodeKey);
    end
    opcode = instructionSet(opcodeKey); % Opcode 변환

    % 3. 오퍼랜드 처리
    regCodes = ''; % 레지스터 코드 초기화
    immediate = ''; % 즉시값 초기화

    if strcmp(opcodeKey, 'MODULATION')
        % MODULATION 명령어 처리 (레지스터 순서를 역순으로)
        if numel(operands) ~= 2
            error('MODULATION 명령어의 오퍼랜드 개수가 잘못되었습니다: %s', line);
        end

        % R12, R9를 역순으로 변환 (R9 -> R12)
        sourceRegister = upper(operands{2}); % R9
        destinationRegister = upper(operands{1}); % R12

        % 레지스터 코드 확인
        if ~isKey(registers, sourceRegister) || ~isKey(registers, destinationRegister)
            error('유효하지 않은 레지스터: %s', line);
        end

        % 레지스터 순서 역순
        regCodes = strcat(registers(sourceRegister), registers(destinationRegister));
        
         elseif strcmp(opcodeKey, 'BLT')
        % BLT 명령어 처리
        if numel(operands) ~= 2
            error('BLT 명령어의 오퍼랜드 개수가 잘못되었습니다: %s', line);
        end

        % 레지스터 처리
        destinationRegister = upper(operands{1}); % R1
        immediateValue = operands{2}; % 즉시값

        if ~isKey(registers, destinationRegister) 
            error('유효하지 않은 레지스터: %s', line);
        end

        % 레지스터 코드
        regCodes = strcat(registers(destinationRegister));

        % 즉시값을 16비트 이진수로 변환
        immediate = dec2bin(str2double(immediateValue), 20);

    elseif strcmp(opcodeKey, 'ADDI') || strcmp(opcodeKey, 'SUBI') || strcmp(opcodeKey, 'RST') || strcmp(opcodeKey, 'LST') || strcmp(opcodeKey, 'BLT')
        if numel(operands) ~= 3
            error('잘못된 오퍼랜드 형식: %s', line);
        end

        % 레지스터 처리
        destinationRegister = upper(operands{1}); % R1
        sourceRegister = upper(operands{2}); % R2
        immediateValue = operands{3}; % 즉시값

        if ~isKey(registers, destinationRegister) || ~isKey(registers, sourceRegister)
            error('유효하지 않은 레지스터: %s', line);
        end

        % 레지스터 코드
        regCodes = strcat(registers(sourceRegister), registers(destinationRegister));

        % 즉시값을 16비트 이진수로 변환
        immediate = dec2bin(str2double(immediateValue), 16);

    elseif contains(line, '(') % SW, LW와 같은 즉시값 명령어
        parts = regexp(operands{2}, '(\d+)\((R\d+)\)', 'tokens', 'once');
        if isempty(parts) || numel(parts) ~= 2
            error('잘못된 오퍼랜드 형식: %s', operands{2});
        end
        immediateValue = parts{1}; % 즉시값
        baseRegister = upper(parts{2}); % 베이스 레지스터 (e.g., R2)

        % 즉시값을 16비트 이진수로 변환
        immediate = dec2bin(str2double(immediateValue), 16);

        % 레지스터 순서: 베이스(R2) -> 대상(R1)
        regCodes = strcat(registers(baseRegister), registers(upper(operands{1})));
    else % 일반 명령어 (e.g., ADD R1 R2 R3) R타입
        if numel(operands) >= 3
            operands = {operands{2}, operands{3}, operands{1}}; % R2, R3, R1 순서로 재배열
        end

        % 레지스터 처리
        for i = 1:numel(operands)
            registerName = upper(operands{i});
            if ~isKey(registers, registerName)
                error('유효하지 않은 레지스터: %s', registerName);
            end
            regCodes = strcat(regCodes, registers(registerName));
        end
    end

    % 4. 기계어 생성
    machineCode = strcat(opcode, regCodes, immediate);

    % 5. 32비트 길이 맞추기
    totalLength = strlength(machineCode);
    if totalLength > 32
        error('생성된 기계어가 32비트를 초과했습니다: %s', machineCode);
    elseif totalLength < 32
        machineCode = pad(machineCode, 32, 'right', '0'); % 오른쪽에 '0' 채우기
    end
end
