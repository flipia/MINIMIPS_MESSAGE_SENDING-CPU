%% ISA & Register
clc; clear;
instructionSet = containers.Map(...
        {'LW', 'SW', 'JMP', 'BLT', 'MERGE', 'ECC_HASH', 'ECC_ADD', 'ECC_MUL', 'MODULATION', ...
         'ADD', 'ADDI', 'SUB', 'SUBI', 'AND', 'COMPARE', 'XOR', 'LST','RST'}, ...
        {'000000','000001', '000010', '000011', '000100', '000101', '000110', '000111','001000', ...
        '001001', '001010', '001011','001100', '001101', '011110', ...
         '011111', '010000', '010001'} ...
         );
 
registers = containers.Map(...
    {'R0', 'R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9', 'R10', ...
     'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20', ...
     'R21', 'R22', 'R23', 'R24', 'R25', 'R26', 'R27', 'R28', 'R29', 'R30', ...
     'R31'}, ...
    {'00000','00001', '00010', '00011', '00100', '00101', '00110', '00111', '01000', '01001', '01010', ...
     '01011', '01100', '01101', '01110', '01111', '10000', '10001', '10010', '10011', '10100', ...
     '10101', '10110', '10111', '11000', '11001', '11010', '11011', '11100', '11101', '11110', ...
     '11111'} ...
    );

%% 입력
% 어셈블리 코드 입력
assemblyCode = {
'LW R2 3(R1)'
'LW R3 5(R1)'
'ADDI R4 R0 33041'
'ECC_HASH R4 R4 R3'
'MERGE R4 R0 R4'
'MODULATION R5 R4'
'LW R6 4(R1)'
'ADDI R7 R0 0'
'LW R8 0(R1)'
'LW R30 4(R1)'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'ECC_ADD R7 R7 R8'
'ECC_ADD R8 R8 R8'
'RST R30 R30 1'
'MODULATION R9 R7'
'LW R10 1(R1)'
'MODULATION R11 R6'
'SUBI R31 R10 2'
'ADDI R12 R0 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R12 R12 R11'
'ECC_MUL R11 R11 R11'
'RST R31 R31 1'
'ECC_MUL R13 R9 R2'
'ADD R14 R5 R13'
'ECC_MUL R15 R12 R14'
'MERGE R16 R9 R15'
}; 

fprintf('입력된 어셈블리 코드:\n'); disp(assemblyCode);

outputFile = fopen('machine_code_output.mem', 'w');
if outputFile == -1
    error('파일을 열 수 없습니다.');
end

fprintf('\n변환된 기계어:\n');
for i = 1:length(assemblyCode)
    line = assemblyCode{i};
    machineCode = assembleLine(line, instructionSet, registers);
    fprintf('%s -> %s\n', line, machineCode);

    % 파일에 기록
    fprintf(outputFile, '%s\n', machineCode); %fprintf(outputFile, '%s -> %s\n', line, machineCode
end

% 파일 닫기
fclose(outputFile);

fprintf('\n Saved at "machine_code_output.txt(mem)".\n');