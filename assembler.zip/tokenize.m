function tokens = tokenize(line)
    % 입력 문자열을 공백으로 분리하여 토큰화
    tokens = split(strtrim(line)); % 앞뒤 공백 제거 후 분리
end