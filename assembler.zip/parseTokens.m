function [opcodeKey, operands] = parseTokens(tokens)
    % 첫 번째 토큰은 명령어
    opcodeKey = upper(tokens{1}); % 명령어를 대문자로 변환
    
    % 나머지 토큰은 레지스터 오퍼랜드
    if numel(tokens) > 1
        operands = tokens(2:end); % 두 번째부터 끝까지
    else
        operands = {}; % 오퍼랜드가 없는 경우
    end
end